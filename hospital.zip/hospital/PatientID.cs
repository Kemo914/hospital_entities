﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace hospital
{
    public class Patient
    {
        public int Patient_ID { get; set; }
        public string First_Name { get; set; }
        public string Last_Name { get; set; }
        public int Date_Of_Birth { get; set; }
        public string Gender { get; set; }
        public string Contact_Number { get; set; }
        public string Address { get; set; }
        public string Email { get; set; }


        public Patient(int patientID, string firstName, string lastName, int dateOfBirth, string gender, string contactNumber, string address, string email)
        {
            Patient_ID = patientID;
            First_Name = firstName;
            Last_Name = lastName;
            Date_Of_Birth = dateOfBirth;
            Gender = gender;
            Contact_Number = contactNumber;
            Address = address;
            Email = email;
        }
    }
}

