﻿using System;
using System.CodeDom;
using hospital;



class program

{
    static void Main(string[] args)
    {
        Doctor doctor = new Doctor(24, "Adelaja", "Olufunwa", "Doctor", "0802367999", "AdeO@gmail.com", " Daren clinic G.A.R street");
        Patient patient = new Patient(12, "Joy", "James", 1996, "Female", "080233336667", "numb3 G.A.R street", "JoyJ@gmail.com");
        Lab_test lab_test = new Lab_test(13, "Blood Test", "Blood analysis", "normal", 50.00m);

        {
            Console.WriteLine($"My name is {doctor.First_Name} {doctor.Last_Name}. I can be contacted via {doctor.Contact_Number} and {doctor.Email}.");
        
            Console.WriteLine($"I understand that your name {patient.First_Name} {patient.Last_Name} a patient that would be carrying out a {lab_test.Test_Name} test. Please confirm {patient.Contact_Number} and {patient.Email} as your email address");
        }

    }
}
